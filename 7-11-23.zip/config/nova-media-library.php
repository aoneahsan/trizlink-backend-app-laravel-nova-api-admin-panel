<?php

return [
    'default-croppable' => true,
    'enable-existing-media' => true,
    'hide-media-collections' => [],
];
