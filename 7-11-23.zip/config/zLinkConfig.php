<?php

return [
  /*
  * Current time add optExpireAddTime will be set as expired time for opt.
  */
  'optExpireAddTime' => 5,

  /*
  * Number of minutes added to user->lastSeenAt.
  */
  'lastSeenAtAddTime'=> 2,

  /*
  * items default limit.
  */
  'defaultLimit' => 30
  
];
