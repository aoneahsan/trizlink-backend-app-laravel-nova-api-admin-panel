<?php

namespace App\Zaions\Enums;


enum FolderModalsEnum: string
{
  case shortlink = 'shortlink';
  case linkInBio = 'linkInBio';
}
