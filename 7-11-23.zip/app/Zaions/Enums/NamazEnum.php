<?php

namespace App\Zaions\Enums;


enum NamazEnum: string
{
  case fajar = 'fajar';
  case zohar = 'zohar';
  case asar = 'asar';
  case magrib = 'magrib';
  case isha = 'isha';
  case juma = 'juma';
}
