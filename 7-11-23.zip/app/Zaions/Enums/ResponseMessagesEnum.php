<?php

namespace App\Zaions\Enums;


enum ResponseMessagesEnum: string
{
  case Unauthorized = 'Invalid access, you are not allowed to access this data.';
}
