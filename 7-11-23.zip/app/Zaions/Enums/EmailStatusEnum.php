<?php

namespace App\Zaions\Enums;

enum EmailStatusEnum: string
{
  case Verified = 'Verified';
  case Unverified = 'Unverified';
}
