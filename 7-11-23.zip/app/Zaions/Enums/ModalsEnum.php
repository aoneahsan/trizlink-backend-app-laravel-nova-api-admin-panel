<?php

namespace App\Zaions\Enums;


enum ModalsEnum: string
{
  case pixel = 'pixel';
  case UTMTag = 'UTMTag';
}
