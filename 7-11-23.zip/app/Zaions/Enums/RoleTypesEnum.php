<?php

namespace App\Zaions\Enums;


enum RoleTypesEnum: string
{
  case mainAppRole = 'mainAppRole';
  case inAppWSRole = 'inAppWSRole';
}
