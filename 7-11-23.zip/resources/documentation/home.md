---
title: "Welcome to your documentation"
path: "welcome"
order: 0
---

# Welcome to your documentation

Within this area, you can:

* Define features
* Add how-to's
* Link to tutorial videos/images

To see any other Markdown syntax and examples, please see [the sample](sample.md).