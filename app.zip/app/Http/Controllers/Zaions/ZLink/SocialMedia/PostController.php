<?php

namespace App\Http\Controllers\Zaions\ZLink\SocialMedia;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PostController extends Controller
{
    //
}
